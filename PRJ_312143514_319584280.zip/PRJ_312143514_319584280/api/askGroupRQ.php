<?php
require_once("../db.php");

session_start();
if(!isset($_SESSION['mail'])){
    header('Location: ../signIN.php');
    exit;
}

$userID= $_POST["userID"];
$grpuoID= $_POST["grpuoID"];

$sql= "INSERT INTO `membersingroup`(`groupID`, `userID`, `status`) 
        VALUES ($grpuoID, $userID, \"RQ\")";

if($conn->query($sql)===true){
    $last_id=$conn->insert_id;
    echo json_encode(array('success' => 1, "id"=>$last_id));
}    
else{
    echo json_encode(array('success' => 0));
}

$conn->close();
?>
